﻿using System;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections.Generic;

namespace twitterDashBoard
{
    public class chartData
    {
        public string word;
        public int wordCnt;
        public chartData(string word, int wordCount)
        {
            this.word = word;
            this.wordCnt = wordCount;
        }
    }

    public class plotData
    {
        public string word;
        public int wordCnt;
        public string date;
        public plotData(string word, int wordCount, string date)
        {
            this.word = word;
            this.wordCnt = wordCount;
            this.date = date;
        }
    }

    public partial class Form1 : Form
    {
        public delegate void ChartingDelegate(List<chartData> chData);
        public delegate void PlottingDelegate(List<plotData> pltData);
        ChartingClass cc = null;
        PlottingClass pc = null;
        bool done = true;
        const int LIMIT = 100;

        Thread chartingThread;
        Thread plottingThread;
        string dt = "";
        static readonly object tight = new object();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ChartingDelegate chartDel = new ChartingDelegate(chartData);
            cc = new ChartingClass(chartDel);
            PlottingDelegate plotDel = new PlottingDelegate(plotLine);
            pc = new PlottingClass(plotDel);


            dt = DateTime.Now.ToString("MM/dd/yyyy H:mm:ss");

            this.chart1.Series.Clear();

            numberBars_mb.Text = "10";

            // Set palette
            this.chart1.Palette = ChartColorPalette.Light;

            // Set title
            this.chart1.Titles.Add("Twitter");    

        }

        private void chartData(List<chartData> chData)
        {
            if (chart1.InvokeRequired)
            {
                var d = new ChartingDelegate(chartData);
                chart1.Invoke(d, new object[] { chData });
            }
            else
            {
                lock (tight)
                {
                    int numBars = 10;

                    int cntr = 0;
                    this.chart1.Series.Clear();

                    if (int.TryParse(numberBars_mb.Text, out numBars))
                    {
                        if (numBars < 200)
                        {
                            // iterate through
                            foreach(twitterDashBoard.chartData cData in chData)
                            {

                                // create series and add data points
                                try
                                {
                                    Series series = this.chart1.Series.Add(cData.word);
                                    series.Points.Add(cData.wordCnt);
                                }
                                catch
                                {

                                }
                                cntr++;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Try a smaller number and re-start.");
                            this.chartingThread.Suspend();
                            start_btn.Text = "Start";
                            done = true;
                        }
                    }

                    // refresh chart
                    this.chart1.ChartAreas[0].RecalculateAxesScale();
                    this.Refresh();
                }
            }
        }

        private void plotLine(List<plotData> pltData)
        {
   

            if (chart2.InvokeRequired)
            {
                var d = new PlottingDelegate(plotLine);
                chart2.Invoke(d, new object[] { pltData});
            }
            else
            {
                lock (tight)
                {
                    int cntr = 0;
 
 
                    foreach(twitterDashBoard.plotData pData in pltData)
                    {

                        // create series and add data points
                        try
                        {
                            //Series series = this.chart1.Series.Add(dr["word"].ToString());
                            this.chart2.Series[0].Points.Add(pData.wordCnt);
                        }
                        catch
                        {

                        }
                        cntr++;
                    }
                    // refresh chart
                    this.chart2.ChartAreas[0].RecalculateAxesScale();
                    this.Refresh();
                    

                }

            }
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            done = true;
        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            done = !done;

            if (!done)
            {
                start_btn.Text = "Stop";
                if (this.chartingThread == null)
                {
                    this.chartingThread = new Thread(new ThreadStart(cc.chartData));
                }
                if (this.plottingThread == null)
                {
                    this.plottingThread = new Thread(new ThreadStart(pc.plotLine));
                }

                if (!chartingThread.IsAlive)
                    this.chartingThread.Start();
                else
                    this.chartingThread.Resume();

                if (!plottingThread.IsAlive)
                    this.plottingThread.Start();
                else
                    this.plottingThread.Resume();
            }
            else
            {
                start_btn.Text = "Start";
                if(this.chartingThread != null)
                    this.chartingThread.Abort();
            }
        }
    }
}
