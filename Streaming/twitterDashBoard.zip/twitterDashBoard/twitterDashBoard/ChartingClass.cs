﻿using System;
using System.Data.Odbc;
using System.Collections.Generic;

namespace twitterDashBoard
{
    class ChartingClass
    {
        bool done = false;
        Form1.ChartingDelegate chartDel;
        OdbcConnection conn = new OdbcConnection();
        OdbcCommand cmd = new OdbcCommand();
        OdbcDataReader dr;
        readonly object tight = new object();
        public int max = 10;

        public int maxBars
        {
            set
            {
                max = value;
            }
            get
            {
                return max;
            }
        }

        public ChartingClass(Form1.ChartingDelegate cd)
        {
            chartDel = cd;

            // open database connection
            conn.ConnectionString = "DSN=twitter";
            cmd.Connection = conn;
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
        }

        ~ChartingClass()
        {
            conn.Close();
        }
 

        public void chartData()
        {
            while (!done)
            {
                // use line graph for this
                string sql = "SELECT word, SUM(wd_count) cnt ";
                sql += "FROM word_count_t ";
                sql += "GROUP BY word ORDER BY SUM(wd_count) DESC";
                lock (tight)
                {


                    cmd.CommandText = sql;
                    dr = cmd.ExecuteReader();


                    List<twitterDashBoard.chartData> chData = new List<chartData>();

                    int cntr = 0;
                    while (dr.Read())
                    {
                        if (cntr < maxBars)
                            chData.Add(new chartData(dr["word"].ToString(), Convert.ToInt32(dr["cnt"])));
                        else
                            break;
                        cntr++;
                    }
                    // close database connection
                    dr.Close();
                    chartDel.Invoke(chData);
                }
            }
        }

 
    }
}
