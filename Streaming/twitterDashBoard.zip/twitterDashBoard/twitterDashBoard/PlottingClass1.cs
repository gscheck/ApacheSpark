﻿using System;
using System.Data.Odbc;
using System.Collections.Generic;

namespace twitterDashBoard
{
    class PlottingClass
    {
        bool done = false;
        Form1.PlottingDelegate plotDel;
        OdbcConnection conn = new OdbcConnection();
        OdbcCommand cmd = new OdbcCommand();
        OdbcDataReader dr;
        string dt = "";
        int max = 100;

        readonly object tight = new object();

        public int maxRecords
        {
            set
            {
                max = value;
            }
            get
            {
                return max;
            }
        }


        public PlottingClass(Form1.PlottingDelegate pd)
        {
            plotDel = pd;
            dt = DateTime.Now.ToString("MM/dd/yyyy H:mm:ss");


            // open database connection
            conn.ConnectionString = "DSN=twitter";
            cmd.Connection = conn;

            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
        }

        ~PlottingClass()
        {
            conn.Close();
        }

        public void plotLine()
        {
            while (!done)
            {
     
                // use line graph for this
                string sql = "SELECT rec_dt, word, SUM(wd_count) cnt ";
                sql += "FROM word_count_t ";
                sql += "WHERE rec_dt >= '" + dt + "' ";
                sql += "GROUP BY minute( rec_dt ), word";

                lock (tight)
                {
 
                    cmd.CommandText = sql;
                    dr = cmd.ExecuteReader();

                    List<twitterDashBoard.plotData> pltData = new List<plotData>();

                    int cntr = 0;
                    while (dr.Read())
                    {
                        if (cntr < maxRecords)
                            pltData.Add(new plotData(dr["word"].ToString(), Convert.ToInt32(dr["cnt"]), dr["rec_dt"].ToString()));
                        else break;

                        cntr++;
                    }
                    // close database connection
                    dr.Close();
                    plotDel.Invoke(pltData);
                }
            }
        }
    }
}
